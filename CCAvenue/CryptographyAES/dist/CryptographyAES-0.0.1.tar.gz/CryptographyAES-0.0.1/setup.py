import setuptools
from setuptools import find_packages
setuptools.setup(
	name = 'CryptographyAES',
	version = '0.0.1',
	author = 'Technykx',
	author_email = 'admin@technykx.com',
	description = 'Test module',
	packages = find_packages(),
	install_requires = []
	)